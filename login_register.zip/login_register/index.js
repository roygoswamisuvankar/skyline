const path = require('path');
const express = require('express');
const mysql = require('mysql');
const ejs = require('ejs');
const bodyparser = require('body-parser');
const session = require('express-session');
const cookieparser = require('cookie-parser');
const { response } = require('express');
const app = express();

//create connection
const conn = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'suvankar'
});
//connect to database
conn.connect((err) => {
    if(err) throw err;
    console.log('connected');
});

//routes
app.set('views', path.join(__dirname, 'views'));
//set view engine
app.set('view engine', 'ejs');
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({ extended : false }));
//satatic files 
app.use(express.static(__dirname + '/public'));

app.use(cookieparser('secret'));
app.use(session({
    secret: 'secret',
    maxAge: 360000,
    resave: true,
    saveUninitialized: true,
}));


//user authenticate
/*const checkauthenticate = function(req, res, next){
    if(req.checkauthenticate()){
        res.set('Cache-Control', 'no-cache, private, no-store, must-revalidate, post-check=0, pre-check=0');
        return next();
    }else{
        res.redirect('/login');
    }
}*/


//route for home page 'GET' methods
//register ejs
app.get('/', (req, res) => {
    res.render('home');
});
app.get('/register', (req, res) => {
    res.render('register');
})
//login ejs
app.get('/login', (req,res) => {
    res.render('login');
});


//route for Other important page 'POST' methods
//register POST
app.post('/register_user', (req, res) => {
    let data = {name: req.body.name, email: req.body.email, password: req.body.password, cpass: req.body.cpass};
    let sql = "insert into user2 set ?";
    let query = conn.query(sql, data, (err, results) => {
        let massage;
        if(err) throw err;
        else{
            massage = "You are registered successfully";
            res.render('login', {'massage' : massage });
        }
    })
})

//login POST
app.post('/login_user', (req, res) => {
   var email = req.body.email;
   var password = req.body.password;
   if(email && password){
        conn.query('select *from user2 where email = ? and password = ?', [email, password], function(error, results, fields) {
            if(results.length > 0){
                req.session.loggedin = true;
                req.session.email = email;
                res.render('welcome', {result : results});
            }else{
                massage = "incorrect";
                res.redirect('/login');
            }
            res.end();
        });
   }else{
        massage = "enter pass";
        res.redirect('/login');
        res.end();
   }
});
//after login goto welcome page
app.get('/welcome', function(req, res) {
    if(req.session.loggedin) {
        res.render('welcome');
    }else{
        res.redirect('/login');
    }
    res.end();
});

app.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/login');
})

//server
app.listen(3050, () => {
    console.log('server running');
});