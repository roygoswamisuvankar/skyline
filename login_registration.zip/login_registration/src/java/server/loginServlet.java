/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.sql.*;
import javax.servlet.http.HttpSession;
/**
 *
 * @author suvankar
 */
public class loginServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
            /* TODO output your page here. You may use following sample code. */
            String fn = request.getParameter("uname");
            String ln = request.getParameter("password");
            
            try{
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/suvankar","root","");
                PreparedStatement ps = con.prepareStatement("select *from users where phone = ? and password = ?");
                
                ps.setString(1, fn);
                ps.setString(2, ln);
                
                ResultSet rs = ps.executeQuery();
                
                while(rs.next()){
                    String name = rs.getString("name");
                    HttpSession session = request.getSession();
                    session.setAttribute("name", name);
                    out.println("<script src='https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.11.4/sweetalert2.all.js'></script>");
                    out.println("<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>");
                    out.println("<script>");
                    out.println("$(document).ready(function(){");
                    out.println("swal('Welcome!','Enjoy your subcription','success');");
                    out.println("})");
                    out.println("</script>");
                    request.getRequestDispatcher("welcome.jsp").include(request, response);
                    
                    return;
                }
                out.println("<script src='https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.11.4/sweetalert2.all.js'></script>");
                out.println("<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>");
                out.println("<script>");
                out.println("$(document).ready(function(){");
                out.println("swal('Wrong Phone No. or Password!','Enter valid Phone No. and Password or Check your are Registered or not','error');");
                out.println("})");
                out.println("</script>");
                request.getRequestDispatcher("newhtml.html").include(request, response);
            }catch(ClassNotFoundException | SQLException se){
                se.printStackTrace();
            }
        }
    }

