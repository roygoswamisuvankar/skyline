/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


package server;

/**
 *
 * @author suvankar
 */
import java.util.*;
import java.sql.*;
public class userDao {
    public static Connection getConnection(){
        Connection con = null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/suvankar","root","");
            
        }catch(Exception e){System.out.println(e);}
        return con;
    }
    public static int save(user e){
        int status = 0;
        
        try{
            Connection con = userDao.getConnection();
            PreparedStatement ps = con.prepareStatement("insert into users(name,birth_date,email,phone,password) values(?,?,?,?,?)");
            ps.setString(1, e.getUser_name());
            ps.setString(2, e.getD_o_b());
            ps.setString(3, e.getEmail());
            ps.setString(4, e.getPhone());
            ps.setString(5, e.getPassword());
            
            status = ps.executeUpdate();
            con.close();
        }catch(SQLException ex){
            ex.printStackTrace();
        }
        return status;
    }

}
